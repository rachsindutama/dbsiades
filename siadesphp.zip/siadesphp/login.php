<?php
echo ("siades");
?>
<!DOCTYPE html>
<html>
<head>
<title>SIADES</title>
<link href="css/memenu.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
    <style>
        body {
         background-color: rgb(255, 255, 255);
        }
      </style>
<div class="top_nav">
    <ul class="memenu skyblue"><li class="active"><a href="index.php">Home</a></li>
				<ul>
					<li><a href="berita.php">Berita</a></li>|
					<li><a href="kependudukan.php">Kependudukan</a></li>|
					<li><a href="administrasi.php">Administrasi</a></li>|
                    <li><a href="wilayah.php">Wilayah</a></li>|
					<li><a href="login.php">Akun Saya</a></li>					
				</ul>
			</div>
            <h2>LOGIN</h2>
                <form>
                    <h5>Username:</h5>	
                    <input type="text" value="">
                    <h5>Password:</h5>
                    <input type="password" value="">					
                    <input type="submit" value="Login">					 
                     <a class="acount-btn" href="register.php"><br>Create an Account</a>
                </form>
                <a href="#">Forgot Password ?</a>           
        </div>
</body>
</html>