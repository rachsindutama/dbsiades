<?php
echo ("siades");
?>
<!DOCTYPE html>'<html>
<head>
<title>SIADES</title>
<link href="css/memenu.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
    <style>
        body {
         background-color: rgb(255, 255, 255);
        }
      </style>
<div class="top_nav">
    <ul class="memenu skyblue"><li class="active"><a href="index.php">Home</a></li>
				<ul>
					<li><a href="berita.php">Berita</a></li>|
					<li><a href="kependudukan.php">Kependudukan</a></li>|
					<li><a href="administrasi.php">Administrasi</a></li>|
                    <li><a href="wilayah.php">Wilayah</a></li>|
					<li><a href="login.php">Akun Saya</a></li>					
				</ul>
			</div>
                    <h3>Kategori Berita</h3>
					<style type="text/css">
		/* Table */
		body {
			font-family: "lucida Sans Unicode", "Lucida Grande", "Segoe UI", vardana
		}
		.demo-table {
			border-collapse: collapse;
			font-size: 13px;
		}
		.demo-table th, 
		.demo-table td {
			padding: 7px 17px;
		}
		.demo-table .title {
			caption-side: bottom;
			margin-top: 12px;
		}
		.demo-table thead th:last-child,
		.demo-table tfoot th:last-child,
		.demo-table tbody td:last-child {
			border: 0;
		}

		/* Table Header */
		.demo-table thead th {
			border-right: 1px solid #c7ecc7;
			text-transform: uppercase;
		}

		/* Table Body */
		.demo-table tbody td {
			color: #353535;
			border-right: 1px solid #c7ecc7;
		}
		.demo-table tbody tr:nth-child(odd) td {
			background-color: #f4fff7;
		}
		.demo-table tbody tr:nth-child(even) td {
			background-color: #dbffe5;
		}
		.demo-table tbody td:nth-child(4),
		.demo-table tbody td:first-child,
		.demo-table tbody td:last-child {
			text-align: right;
		}
		.demo-table tbody tr:hover td {
			background-color: #ffffa2;
			border-color: #ffff0f;
			transition: all .2s;
		}

		/* Table Footer */
		.demo-table tfoot th {
			border-right: 1px solid #c7ecc7;
		}
		.demo-table tfoot th:first-child {
			text-align: right;
		}
	</style>
</head>
<body>
	<table class="demo-table">
		<caption class="title">Tabel 1. Kategori Berita</caption>
		<thead>
			<tr>
				<th>No</th>
				<th>Berita</th>
				<th>id_jns_berita</th>
				<th>klik berita</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>1</td>
				<td>Olahraga</td>
				<td>org_001</td>
				<td><a href="#">Pilih</a></td>
			</tr>
			<tr>
				<td>2</td>
				<td>Dunia Politik</td>
				<td>ptk_001</td>
				<td><a href="#">Pilih</a></td>
			</tr>
			<tr>
				<td>3</td>
				<td>Kriminalitas</td>
				<td>krm_001</td>
				<td><a href="#">Pilih</a></td>
			</tr>
			<tr>
				<td>4</td>
				<td>Bisnis Desa</td>
				<td>bsd_001</td>
				<td><a href="#">Pilih</a></td>
			</tr>
			<tr>
				<td>5</td>
				<td>Pendidikan</td>
				<td>pdk_001</td>
				<td><a href="#">Pilih</a></td>
			</tr>
		</tbody>
	</table>
</body>
</html>